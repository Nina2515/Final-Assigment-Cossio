import BaseScene from './BaseScene';


class PlayScene extends BaseScene {
  constructor (sharedConfig){
    super("PlayScene")
    this.config = sharedConfig;

    this.bird = null;
    this.brick = null;

   
    this.BrickHorizontalDistance = 0;
    this.BrickVerticalDistanceRange = [150, 250];
    this.BrickHorizontalDistanceRange = [500, 550];
    this.flapVelocity = 300;

    this.score = 0;
    this.scoreText = '';
  }

  preload() {
    let url = 'https://raw.githubusercontent.com/rexrainbow/phaser3-rex-notes/master/dist/rexvirtualjoystickplugin.min.js';
    this.load.plugin('rexvirtualjoystickplugin', url, true);
    
  }


  

  create() {
    super.create()
    this.createBird();
    this.createBrick();
    this.createColliders();
    this.createScore();
    this.createPause();
    this.createEventHandler();
    this.createMyButton();
    this.createJoystick();
   
  }

createJoystick(){
  this.joyStick = this.plugins.get('rexvirtualjoystickplugin').add(this, {
    x: 55,
    y: 400,
    radius: 100,
    base: this.add.circle(0, 0, 50, 0x888888),
    thumb: this.add.circle(0, 0, 25, 0xcccccc),
    forceMin: 50,
});

on('update', this.dumpJoyStickState, this);

this.joystickCursors = this.joyStick.createCursorKeys();
this.cursors = this.input.keyboard.createCursorKeys();
}


dumpJoyStickState() {
  var cursorKeys = this.joyStick.createCursorKeys();
  console.log('Force: ', this.joyStick.force);
  console.log('Angle: ', this.joyStick.angle);
}

update() {
  if (this.cursors.up.isDown || this.joystickCursors.up.isDown ) {
      
  }
}


  createMyButton(){

    const Bottom = this.add.image(this.config.width/80, this.config.height/60,"sky").setScale(0.04);

    Bottom.on('pointerdown', this.changeScene,this);


  }

  changeScene(){
    this.scene.start('Scene')
  }

  update(){
    this.checkCollision();
    this.recycleBrick();

  }

  createPause() {
    let float= 30.23;
    const pauseButton = this.add.image(this.config.width/float -10, this.config.height/float -10, 'pause')
    .setInteractive()
      .setScale(3)
      .setOrigin(1);

      pauseButton.on('pointerdown', () => {
        this.physics.pause();
        this.scene.pause();
      })
  }


  createColliders() {
    this.physics.add.collider(this.bird, this.pipes, this.gameOver, null, this);
    this.physics.add.collider(this.stars, this.platforms);
    this.physics.add.collider(this.bombs, this.platforms, this.gameOver, null , this);
  }


  checkGameStatus() {
    if (this.bird.getBounds().bottom >= this.config.height || this.bird.y <= 0) {
      this.gameOver();
    }

    this.checkGameStatus();
    this.recycleBrick();
  }

  createBG() {
    this.add.image(0, 0, 'sky').setOrigin(0);
  }

  createBird() {

    this.bird = this.physics.add.sprite(this.config.startPosition[0], this.config.startPosition[1], 'bird').setOrigin(0).setScale(0.1); 
    this.bird.body.gravity.y = 600;
    this.bird.setCollideWorldBounds(true);
  }

  createBrick() {
    this.brick = this.physics.add.group();

    for (let i = 0; i < BRICK_TO_RENDER; i++) {
      let upperBrick = this.pipes.create(0,this.config.height*8/10,'brick').setOrigin(1,1).setImmovable(true);
      let lowerBrick = this.pipes.create(0,this.config.height*8/10,'brick').setOrigin(0,1).setImmovable(true);

      this.placeBrick(upperBrick, lowerBrick)
    }

    this.brick.setVelocityY(200);
  }

  placeBrick(upperBrick, lowerBrick) {
    const BrickVerticalDistance = Phaser.Math.Between(...this.BrickVerticalDistanceRange);
    const BrickVerticalPosition = Phaser.Math.Between(20, this.config.height - 20 - BrickVerticalDistance);
    const BrickHorizontalDistance = Phaser.Math.Between(...this.BrickHorizontalDistanceRange);

    upperBrick.x = BrickVerticalPosition;
    upperBrick.y = this.getUpMostBrick() - BrickHorizontalDistance;

    lowerBrick.x = BrickVerticalPosition + BrickVerticalDistance;
    lowerBrick.y = upperBrick.y;
  }

  getUpMostBrick() {
    let UpMost = 0;

    this.brick.getChildren().forEach(function(brick) {
      UpMost= Math.min(brick.y, UpMost);
    })

    return UpMost;
  }

  recycleBrick() {
    const tempBrick = [];
    this.brick.getChildren().forEach(brick => {

      if (brick.y - brick.body.height > this.config.height) {

        tempBrick.push(brick);

        if (tempBrick.length === 2) {
          this.placeBrick(...brick);
        }
      }
    })
  }

  createanims(){
    this.anims.create({
      key: 'turn',
      frames: [ { key: 'bird', frame: 4 } ],
      frameRate: 20
  });

  this.anims.create({
      key: 'right',
      frames: this.anims.generateFrameNumbers('bird', { start: 5, end: 8 }),
      frameRate: 10,
      repeat: -1
  });

  cursors = this.input.keyboard.createCursorKeys();

  
  star = this.physics.add.group({
      key: 'star',
      repeat: 11,
      setXY: { x: 12, y: 0, stepX: 70 }
  });

  star.children.iterate(function (child) {

      child.setBounceY(Phaser.Math.FloatBetween(0.4, 0.8));

  });

  bombs = this.physics.add.group();
  }

  collectStar (bird, star)
{
    star.disableBody(true, true);

    score += 10;
    scoreText.setText('Score: ' + score);

    if (star.countActive(true) === 0)
    {
       
        star.children.iterate(function (child) {

            child.enableBody(true, child.x, 0, true, true);

        });

        var x = (bird.x < 400) ? Phaser.Math.Between(400, 800) : Phaser.Math.Between(0, 400);

        var bomb = bombs.create(x, 16, 'bomb');
        bomb.setBounce(1);
        bomb.setCollideWorldBounds(true);
        bomb.setVelocity(Phaser.Math.Between(-200, 200), 20);
        bomb.allowGravity = false;

    }
}

  hitBomb (bird, bomb)
{
  
    this.physics.pause();

    bird.setTint(0xff0000);

   bird.anims.play('turn');

    gameOver = true;
}

  checkCollision(){

    if(this.bird.getBounds().bottom >= this.config.height || this.bird.y <=0){

      this.gameOver();
    } 

  }


}

export default PlayScene;



 